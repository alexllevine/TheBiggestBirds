int IN1pin = 8;
//active pin 1 for the motor
int IN2pin = 7;
//active pin 2 for the motor
int ENApin = 3;
//controls motor speed
int READpin = 4;
//reads the button input
int doorPosition = 0;
//door position (0 is closed, 1 is open)

void openDoor() { //opens the door
  Serial.println("Opening Door...  ");
  digitalWrite(IN1pin, HIGH);
  digitalWrite(IN2pin, LOW);
  analogWrite(ENApin, 255); 
  delay(3000); //how long the motor runs for in milisecons
  digitalWrite(IN1pin, LOW);
  digitalWrite(IN2pin, LOW);
  analogWrite(ENApin, 0);
  doorPosition = 1;
}

void closeDoor() { //closes the door
  Serial.println("Closing Door...  ");
  digitalWrite(IN1pin, LOW);
  digitalWrite(IN2pin, HIGH);
  analogWrite(ENApin, 255);
  delay(3000); //how long the motor runs for in miliseconds
  digitalWrite(IN1pin, LOW);
  digitalWrite(IN2pin, LOW);
  analogWrite(ENApin, 0);
  doorPosition = 0;
}

void doorMaster() { //the function that opens and closes the door
  if(doorPosition == 0) {
    openDoor();
    delay(3000); //delay before closing
    closeDoor();
  } else {
    Serial.println("You do not have permission");
  }

}

void IRFunction() { //to open the door when power is pressed
  static int i = 1;
  
  if(i % 2 == 1) { //to swap between opening and closing
    Serial.println("LET THE BIRDS RUN FREE"); //open door 
    openDoor();
    delay(200);
    i = 2;
  } else { 
    Serial.println("TAKE COVER"); //close door
    closeDoor();
    delay(200);
    i = 1;
  }
}
